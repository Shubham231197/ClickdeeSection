import logo from "./logo.svg";
import "./App.css";
import TargetImg from "../src/assets/target.png"
import MedalImg from "../src/assets/medal.jpg"
import RainboxImg from "../src/assets/rainbox circle.webp"
import CustomerSupport from "../src/assets/customercare.png"
import Quality from "../src/assets/no1.jpg"

function App() {


  return (
    <div className="App">
      <div className="row-container">
        <div className="col-container">
          <h2>Why the industry Chooses Clickdee?</h2>
          <p>
            We understand performace marketing from very angle and every stage
            of the funnel.our Clients trust that we know that netrices move
            their business towards growth .Our publisher and affiliate partners
            know that we make maximum revenuue and roas a main focus when
            growing and partnership
          </p>
        </div>
        <div className="col-container-25">
          <img src={TargetImg}/>
          <h3>
            Choose Your Local Targeting
          </h3>
          <p className="container-on-hover">
            Our targeted and tracked calls  are tailbored  to your buisness needs ,audience, and geolocation 
          </p>
        </div>
        <div className="col-container-25">
          <img src={MedalImg}/>
          <h3>
            Choose Your Local Targeting
          </h3>
          <p className="container-on-hover">
            Our targeted and tracked calls  are tailbored  to your buisness needs ,audience, and geolocation 
          </p>
        </div>
      </div>
      <div className="row-container">
        <div className="col-container-25 w-20">
         
        </div>
        <div className="col-container-25">
          <img src={RainboxImg}/>
          <h3>
            Choose Your Local Targeting
          </h3>
          <p className="container-on-hover">
            Our targeted and tracked calls  are tailbored  to your buisness needs ,audience, and geolocation 
          </p>
        </div>
        <div className="col-container-25">
          <img src={CustomerSupport}/>
          <h3 >
            Choose Your Local Targeting
          </h3>
          <p className="container-on-hover">
            Our targeted and tracked calls  are tailbored  to your buisness needs ,audience, and geolocation 
          </p>
        </div>
        <div className="col-container-25">
          <img src={Quality}/>
          <h3>
            Choose Your Local Targeting
          </h3>
          <p className="container-on-hover">
            Our targeted and tracked calls  are tailbored  to your buisness needs ,audience, and geolocation 
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
